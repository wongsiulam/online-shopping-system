const iconStore = [
    '&#xe600;',
    '&#xe8c7;',
    '&#xe617;',
    '&#xe709;',
    '&#xe618;',
    '&#xe601;',
    '&#xe631;',
    '&#xe73d;',
    '&#xe60a;',
    '&#xe609;',
    '&#xe608;',
    '&#xe607;',
    '&#xe606;',
    '&#xe605;',
    '&#xe604;',
    '&#xe603;',
    '&#xe602;',
];
export default
{
    iconStore,

}　