<!--
 * 后台管理欢迎页
 *
 
-->
<template>
<div style="text-align: center;width: 100%;font-size: 32px;">
  <h1>网上购物商城后台管理系统</h1>
</div>
</template>

<script>

export default {
  name: "Home.vue"
}

</script>
