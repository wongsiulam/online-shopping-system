<!--
 * app主页
 *
-->
<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>

@import "./resource/css/icon.css";
</style>


