<!--
 * 页面未找到 404跳转
 *
 
-->
<template>
<h1>404 Not Found</h1>
</template>

<script>
export default {
  name: "404"
}
</script>

<style scoped>

</style>
